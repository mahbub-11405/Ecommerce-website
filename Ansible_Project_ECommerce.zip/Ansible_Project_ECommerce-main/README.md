# Ansible_Project_ECommerce

# Introduction

This is a sample e-commerce application built for learning purposes using Ansible

Here's how to deploy it on CentOS systems:

## Deploy Pre-Requisites

1. Install FirewallD

## Deploy and Configure Database

1. Install MariaDB

2. Configure firewall for Database

3. Configure Database

4. Load Product Inventory Information to database


## Deploy and Configure Web

1. Install required packages

2. Configure httpd

3. Start httpd

4. Download code

5. Update index.php

6. Test

## Verification

curl http://localhost
or
http://server_ip:http_port


